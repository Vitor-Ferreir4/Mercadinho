﻿using Microsoft.EntityFrameworkCore;
using StudentApp.Models.Models;
using System.Collections.Generic;
namespace StudentApp.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext>options) : base(options)
        {
        }
        public DbSet<Estudante_cad> Students { get; set; }
        internal bool TestConnection()
        {
            throw new NotImplementedException();
        }
    }
}
